#!/bin/bash
mkdir build
